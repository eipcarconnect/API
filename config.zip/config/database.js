module.exports = {
	'secret':'nodeauthsecret12345',
	'database':'mongodb://apiuser:5tuipAx4dv@database-carconnect:27017/api',
	'firebase':'firebase-adminsdk-hh0f7@carconnect-e09c5.iam.gserviceaccount.com'
    };